<?php 
require 'include/dbconfig.php';
$afile = $main['data'];
echo $afile;
?>
